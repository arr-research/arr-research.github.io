import json, hashlib
from pathlib import Path
from datetime import datetime, timezone
root=Path(r'D:\Temp\airr\2026-10-17_astra-sharp-constant-final')
now=datetime.now(timezone.utc).isoformat(timespec='seconds')
pdfhash='93a079895bad4695bbe1f3e31488531b3b53cd4ab614e39254fdc659460a1e2c'
texhash='558d43f0c271ff9b5cd0488c492604c349ab9fe7d0b4cfe154b1e7db09e7f44e'
assessment={
 'paper_id':'ARR-2026-418PW0QXGN812RDC',
 'version':'v1',
 'version_id':'arr:version:f64edeef-9524-4d44-aba0-fe823f75dae0',
 'canonical_sha256':pdfhash,
 'provider':'OpenAI',
 'model_id':'gpt-6-astra',
 'assessed_at':now,
 'prompt_version':'ARR-ASSESS-1.0',
 'independence':'involved_in_manuscript',
 'recommendation':'minor_revision',
 'millennium_score':5.8,
 'overall_stars':6,
 'criteria':{
  'correctness_confidence':{'stars':4,'basis':'Reconstruidos balance, recurrencia MP, transferencia uniforme en todo m, cortes y max-flow, estimación GJN con p proporcional a log d, márgenes de Gram y producto Gamma. Las hipótesis de las fuentes primarias examinadas encajan. No se detectó objeción material; la conclusión sigue condicionada a los teoremas externos, sin certificación formal ni humana.'},
  'rigor':{'stars':5,'basis':'La prueba separa las dos dificultades reales: uniformidad sobre todas las amplificaciones y capacidad en dimensión creciente. Explicita los cuantificadores, conserva el cuadrado del momento GJN, reserva márgenes antes de normalizar y no intercambia un límite de m fijo con un supremo. La precisión notacional indicada no afecta al argumento.'},
  'novelty':{'stars':3,'basis':'La aportación plausible es la sharpness de la comparación irrestricta, incluso con Gram identidad, junto con el límite F_infinito/F_1 para s fijo. El balance previo, la ley libre, el factor e, la aproximación polinómica y los estimadores gaussianos son antecedentes reconocidos. La búsqueda fue dirigida, no exhaustiva ni certificadora de prioridad.'},
  'significance':{'stars':3,'basis':'Determina exactamente una constante universal y descarta el factor 2 en la clase completa. Es un resultado técnico sustantivo en un problema especializado; no aporta testigos pequeños explícitos, tasa de dimensión, algoritmo efectivo ni consecuencias amplias demostradas.'},
  'reproducibility':{'stars':5,'basis':'Verificadas las 13 entradas del manifiesto, el PDF de 11 páginas y la fuente exacta. El verificador suministrado se ejecutó en copia escribible y reprodujo exactamente su JSON PASS. Controles propios adicionales de MP, Gamma, cortes y orientación compleja de Gram pasaron, incluido un control negativo. Esas pruebas finitas no certifican los límites probabilísticos.'}
 },
 'summary':'El PDF exacto desarrolla una prueba coherente y completa a nivel de nota de investigación de la optimalidad de e, usando una transferencia finita uniforme y una cota de capacidad por cortes. No encuentro un defecto que invalide los enunciados principales. Recomiendo una corrección notacional menor en la última frase de la prueba de la proposición 15. Calidad ordinaria: 8.8/10; importancia AIRR: 5.8/10, escalas distintas. La recomendación científica no es una decisión editorial Accepted. Se declara involved_in_manuscript por participación previa de la familia de modelos. Este agente recibió un encargo nuevo sin historial de construcción, pero ni el aislamiento de memoria ni la identidad real del runtime están atestados independientemente; gpt-6-astra/xhigh es la configuración solicitada/declarada. Una búsqueda externa devolvió incidentalmente extractos de una evaluación con puntuaciones del antecedente Hermitiano ARR-2026-4E4SJ328XF98BSCJ; no se abrió la ficha ni se vio una evaluación del manuscrito actual. Por ello no se afirma revisión ciega, independiente ni humana.',
 'strengths':[
  'La proposición 5 controla todos los m con una única lista finita de momentos, incluso cuando los maximizadores dependen de A y de m.',
  'El lema 7 prueba capacidad mediante cortes válidos en todas las bases; evita deducir continuidad uniforme de la mera cercanía de las dos marginales.',
  'La especialización GJN usa sólo el desacoplamiento gaussiano y la estimación de traza, retiene el cuadrado y vence el factor d^2 con p de orden log d.',
  'La normalización exacta de Gram tiene orientación compleja correcta y márgenes explícitos; la proposición 15 dispone de una cota inferior Gamma que no depende de la comparación C/e.',
  'El texto distingue claramente sus antecedentes, el orden de límites y las limitaciones de la construcción.'
 ],
 'weaknesses':[
  'La construcción es existencial y no da una dimensión efectiva ni una tupla pequeña explícita; el coste de aproximación polinómica tampoco está cuantificado.',
  'La identificación de la constante óptima importa la comparación universal de un antecedente del mismo autor; se examinó la parte pertinente de esa dependencia, sin convertir esta evaluación en una nueva revisión integral de todos sus resultados.',
  'La importancia fuera de este funcional especializado y la prioridad mundial no están demostradas.',
  'La procedencia involucrada, la exposición incidental a una evaluación del antecedente y la falta de atestación independiente del runtime impiden presentar este informe como peer review independiente.'
 ],
 'potential_errors':[
  'Menor, p. 10, última frase de la prueba de la proposición 15: G_d, como matriz de Gram, siempre está definido; lo que puede no estar definido es B^(d) mediante G_d^(-1/2). Sustituir la referencia a G_d indefinido por G_d singular o B^(d) no definido. Para Ginibre y s fijo, G_d es invertible casi seguramente cuando d^2 >= s, de modo que esta precisión no afecta al límite.'
 ],
 'strong_novelty_candidates':[
  'Optimalidad del factor e para el supremo de determinantes con energía Hilbert-Schmidt sobre todas las amplificaciones, conservada dentro de la clase de Gram identidad.',
  'Ausencia asintótica de ganancia por amplificación para toda cantidad fija s de coeficientes Ginibre y sus tuplas normalizadas.',
  'Criterio suficiente de capacidad con pérdida epsilon+2q mediante cortes en todas las bases, útil en el régimen de s fijo y d creciente; la conexión general expansión-capacidad no se reclama nueva.'
 ],
 'unresolved_material_objections':[]
}
(root/'assessment-original.json').write_text(json.dumps(assessment,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
summary={
 'paper_id':assessment['paper_id'],'version':'v1','version_id':assessment['version_id'],'assessed_at':now,
 'canonical_pdf_sha256':pdfhash,'canonical_tex_sha256':texhash,
 'recommendation':'minor_revision','unresolved_material_objections':[],
 'ordinary_quality_score':8.8,'ordinary_quality_scale':'0-10: calidad científica y expositiva ordinaria, separada de importancia',
 'airr_importance_score':5.8,'airr_importance_overall_stars':6,
 'quality_basis':'Prueba cuidada, cuantificadores correctos, fuentes principales bien utilizadas y verificaciones reproducidas; una precisión notacional menor.',
 'importance_basis':'Constante universal óptima y resultado uniforme sustantivo, pero de alcance especializado, sin consecuencia amplia ni construcción efectiva demostrada.',
 'pdf_review':{'pages':11,'bytes':129005,'all_pages_rendered_and_visually_inspected':True,'full_text_read':True,'material_layout_defects_found':False},
 'packet_manifest':{'entries':13,'all_hashes_match':True},
 'author_verifier':{'executed_in_writable_copy':True,'status':'PASS','exact_json_match':True,'rational_cases':30780,'enumerated_cuts':201952},
 'own_auxiliary_checks':{'status':'PASS','cut_algebra_grid_cases':1389080,'negative_control_detected_wrong_complex_transpose':True,'limitations':'Controles finitos y numéricos auxiliares, no prueba de los límites ni optimización de F_infinito.'},
 'provenance':{
  'independence':'involved_in_manuscript',
  'configured_model':'gpt-6-astra','requested_reasoning_effort':'xhigh',
  'runtime_identity_independently_attested':False,'memory_isolation_independently_attested':False,
  'fresh_task_without_construction_history':True,
  'incidental_prior_assessment_exposure':'Una búsqueda externa devolvió extractos y puntuaciones de una evaluación del antecedente Hermitiano ARR-2026-4E4SJ328XF98BSCJ. No se abrió la ficha ni se solicitó dicha evaluación; se comunicó el incidente al coordinador y se restringieron las búsquedas posteriores a fuentes primarias.',
  'current_manuscript_other_review_seen':False,
  'blind_review_claimed':False,'independent_peer_review_claimed':False,'human_peer_review_claimed':False,
  'editorial_acceptance_claimed':False
 },
 'files':{'assessment':'assessment-original.json','report':'dictamen.txt','own_checks':'auxiliary-checks.json','author_rerun':'author-verifier-rerun.json','manifest_verification':'packet-verification.json'}
}
(root/'final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'assessed_at':now,'assessment_written':True,'summary_written':True}))

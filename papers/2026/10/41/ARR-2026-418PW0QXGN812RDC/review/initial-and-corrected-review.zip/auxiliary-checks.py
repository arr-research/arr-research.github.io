import json, math
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.special import digamma, polygamma
root=Path(r'D:\Temp\airr\2026-10-17_astra-sharp-constant-final')
rng=np.random.default_rng(20261017)
results={}
# Independent scalar MP integrals under x=4 sin(theta)^2.
def mp_integral(f):
    return quad(lambda a: 4/math.pi*math.cos(a)**2*f(4*math.sin(a)**2),0,math.pi/2,epsabs=1e-11)[0]
results['mp_log_integral']=mp_integral(math.log)
results['mp_moments']=[{'j':j,'integral':mp_integral(lambda x,j=j:x**j),'catalan':math.comb(2*j,j)//(j+1)} for j in range(7)]
results['regularization']=[{'t':t,'ell_plus_one':mp_integral(lambda x,t=t:math.log(x+t))+1,'bound':2*math.sqrt(t)} for t in [1e-8,1e-5,0.001,0.1,1,10]]
# Exact sum identities checked independently against special-function evaluation.
results['gamma']=[{'d':d,'mean_direct':float(np.mean(digamma(np.arange(1,d+1)))-math.log(d)),'mean_formula':float(sum(1/k for k in range(1,d+1))-1-np.euler_gamma-math.log(d)),'variance_direct':float(np.sum(polygamma(1,np.arange(1,d+1)))/d**2),'variance_bound':(sum(1/k for k in range(1,d+1))+1)/d**2} for d in [1,2,3,10,100,1000]]
# Test each algebraic cut branch across all integer cuts for small d and a grid of admissible epsilon,q.
mins={1:1e9,2:1e9,3:1e9}; counts={1:0,2:0,3:0}
for d in range(1,41):
  for eps in np.linspace(0,0.5,11):
    for q in np.linspace(0,(0.5-eps)/2,11):
      c=1-eps-2*q
      for a in range(d+1):
        for b in range(a):
          v=d-b;u=d-a
          if a<=c*d:
            branch=1;lower=(1-eps-q)*a-a*b/d
          elif v<=c*d:
            branch=2;lower=(1-eps-q)*v-u*v/d
          else:
            branch=3;lower=(1-q/c)*a*v/d
          residual=lower-c*(a-b)
          mins[branch]=min(mins[branch],residual);counts[branch]+=1
results['cut_algebra_grid']={'minimum_residuals':mins,'case_counts':counts}
# Complex Gram whitening: check correct orientation and a deliberately wrong transpose as a negative control.
s,d=5,7
A=(rng.standard_normal((s,d,d))+1j*rng.standard_normal((s,d,d)))/math.sqrt(2*d)
A[1]+=0.6j*A[0]
G=np.einsum('iab,jab->ij',A.conj(),A)/d
vals,vecs=np.linalg.eigh(G)
T=(vecs*(vals**-0.5))@vecs.conj().T
B=np.einsum('iab,ij->jab',A,T)
GB=np.einsum('iab,jab->ij',B.conj(),B)/d
sqrtG=(vecs*(vals**0.5))@vecs.conj().T
z=sqrtG[:,0]
wrong=np.einsum('iab,ji->jab',A,T)
wrongG=np.einsum('iab,jab->ij',wrong.conj(),wrong)/d
results['gram_orientation']={'correct_residual':float(np.linalg.norm(GB-np.eye(s))),'reconstruction_residual':float(np.linalg.norm(np.einsum('jab,j->ab',B,z)-A[0])),'coefficient_energy_residual':float(abs(np.vdot(z,z)-G[0,0])),'wrong_transpose_negative_control_residual':float(np.linalg.norm(wrongG-np.eye(s)))}
results['constants']={'c_at_4096':1-23/math.sqrt(4096),'ratio_lower_counterexample_to_2':233/256*math.exp(19/20)}
assert abs(results['mp_log_integral']+1)<1e-10
assert all(abs(r['integral']-r['catalan'])<1e-8 for r in results['mp_moments'])
assert all(-1e-10<=r['ell_plus_one']<=r['bound']+1e-10 for r in results['regularization'])
assert all(abs(r['mean_direct']-r['mean_formula'])<1e-10 and r['variance_direct']<=r['variance_bound']+1e-12 for r in results['gamma'])
assert min(mins.values())>-1e-12
assert results['gram_orientation']['correct_residual']<1e-12
assert results['gram_orientation']['reconstruction_residual']<1e-12
assert results['gram_orientation']['wrong_transpose_negative_control_residual']>0.1
results['all_auxiliary_checks_passed']=True
(root/'auxiliary-checks.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps({'all_auxiliary_checks_passed':True,'cuts_tested':sum(counts.values()),'cut_minimum':min(mins.values()),'gram_residual':results['gram_orientation']['correct_residual'],'negative_control_residual':results['gram_orientation']['wrong_transpose_negative_control_residual'],'mp_log_integral':results['mp_log_integral']}))

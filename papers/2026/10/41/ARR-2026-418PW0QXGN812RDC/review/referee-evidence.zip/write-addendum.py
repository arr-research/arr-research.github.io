import json,hashlib,copy,math
from pathlib import Path
from datetime import datetime,timezone
root=Path(r'D:\Temp\airr\2026-10-17_astra-sharp-constant-final')
out=root/'corrected'
old_manifest=json.loads((root/'review-output-sha256.json').read_text())
assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in old_manifest.items())
old_a=json.loads((root/'assessment-original.json').read_text(encoding='utf-8'))
a=copy.deepcopy(old_a)
a['canonical_sha256']='1eaea4ec8f9a53ed894f58f9af3e33984e824aa074b7a74a8e90fdf6939c1224'
a['assessed_at']=datetime.now(timezone.utc).isoformat(timespec='seconds')
a['recommendation']='accept'
a['criteria']['rigor']['basis']='La prueba separa uniformidad sobre todas las amplificaciones y capacidad en dimensión creciente. Explicita los cuantificadores, conserva el cuadrado del momento GJN, reserva márgenes antes de normalizar y no intercambia un límite de m fijo con un supremo. La única precisión notacional solicitada está corregida y no queda una revisión científica requerida.'
a['criteria']['reproducibility']['basis']='Verificadas las 13 entradas del nuevo manifiesto, el PDF de 11 páginas y el cambio exacto de fuente. Sólo difiere el texto de la página 10, que fue renderizada e inspeccionada. El verificador y su JSON permanecen idénticos a los que se ejecutaron y reprodujeron exactamente en la revisión inicial; no se atribuye una ejecución nueva a esta actualización. Los controles finitos propios siguen siendo auxiliares, no pruebas de los límites probabilísticos.'
a['summary']='Addendum y evaluación del PDF corregido exacto, en el mismo contexto de revisión. La única modificación sustituye la referencia incorrecta a G_d indefinido por el evento de G_d singular, resolviendo la observación de la proposición 15. No encuentro objeciones materiales ni revisiones científicas pendientes; recomiendo accept como juicio científico, no como decisión editorial Accepted. Se conserva la conclusión de que la prueba de optimalidad de e es coherente y completa a nivel de nota de investigación. Calidad ordinaria: 8.8/10; importancia AIRR: 5.8/10, sin cambios y en escalas distintas. Se declara involved_in_manuscript por participación previa de la familia de modelos y esta actualización reutiliza la revisión inicial; no constituye otro voto independiente. gpt-6-astra/xhigh es la configuración solicitada/declarada, sin atestación independiente del runtime ni del aislamiento de memoria. Durante la revisión inicial una búsqueda devolvió incidentalmente extractos y puntuaciones de una evaluación del antecedente Hermitiano ARR-2026-4E4SJ328XF98BSCJ; no se abrió esa ficha ni se vio una evaluación ajena del manuscrito actual. No se afirma revisión ciega, independiente ni humana.'
a['potential_errors']=[]
assert set(a)==set(old_a)
assert a['millennium_score']==5.8 and a['overall_stars']==6
(out/'assessment-original.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=json.loads((root/'final-summary.json').read_text(encoding='utf-8'))
s['assessed_at']=a['assessed_at']
s['canonical_pdf_sha256']=a['canonical_sha256']
s['canonical_tex_sha256']='ff5d9bd999d24efdf2cbb560d048af50c126fe27041be2428ad9c68d7d9e103a'
s['recommendation']='accept'
s['quality_basis']='Se mantiene la evaluación de prueba cuidada, cuantificadores correctos y fuentes principales bien utilizadas. La única precisión notacional solicitada está resuelta; no cambia la aportación científica.'
s['pdf_review']={'pages':11,'bytes':129011,'review_kind':'exact-version addendum in the same review context','full_text_compared_page_by_page':True,'changed_text_pages':[10],'newly_rendered_and_visually_inspected_pages':[10],'prior_pdf_all_pages_visually_inspected':True,'material_layout_defects_found':False}
s['packet_manifest']={'entries':13,'all_hashes_match':True,'source_change_exactly_requested':True}
s['author_verifier']={'executed_in_initial_review_in_writable_copy':True,'rerun_for_this_addendum':False,'unchanged_byte_for_byte':True,'supplied_results_unchanged_byte_for_byte':True,'initial_execution_status':'PASS','initial_exact_json_match':True,'initial_rational_cases':30780,'initial_enumerated_cuts':201952}
s['provenance'].pop('fresh_task_without_construction_history',None)
s['provenance']['initial_review_started_as_fresh_task_without_construction_history']=True
s['provenance']['this_addendum_reuses_initial_review_context']=True
s['provenance']['new_independent_vote']=False
s['prior_evaluation']={'pdf_sha256':old_a['canonical_sha256'],'assessment_sha256':old_manifest['assessment-original.json'],'recommendation':'minor_revision','original_files_preserved':True}
s['resolved_observation']='Proposición 15, última frase: G_d es una matriz de Gram siempre definida; ahora se refiere correctamente al evento G_d singular y a la definición arbitraria de B^(d) en ese evento.'
s['files']={'assessment':'assessment-original.json','report':'dictamen.txt','summary':'final-summary.json','verification':'correction-verification.json','page_diff':'page-10-text-diff.txt','prior_own_checks':'../auxiliary-checks.json','prior_author_rerun':'../author-verifier-rerun.json'}
(out/'final-summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'assessed_at':a['assessed_at'],'recommendation':a['recommendation'],'quality':s['ordinary_quality_score'],'importance':a['millennium_score'],'originals_unchanged':True}))

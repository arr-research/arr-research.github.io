from pathlib import Path
import json, hashlib, difflib
from pypdf import PdfReader
old=Path(r'D:\Temp\airr\2026-10-17_constante-optima\review-packet')
new=Path(r'D:\Temp\airr\2026-10-17_constante-optima\review-packet-corrected')
out=Path(r'D:\Temp\airr\2026-10-17_astra-sharp-constant-final\corrected')
m=json.loads((new/'manifest-sha256.json').read_text(encoding='utf-8-sig'))
checks=[{'path':k,'expected':v,'actual':hashlib.sha256((new/k).read_bytes()).hexdigest()} for k,v in m.items()]
assert len(checks)==13
assert all(x['expected']==x['actual'] for x in checks)
a=(old/'main.tex').read_text(encoding='utf-8'); b=(new/'main.tex').read_text(encoding='utf-8')
before='For the finitely many dimensions in which $G_d$ is undefined,\none may define $B^{(d)}$ arbitrarily; their probability tends\nto zero.'
after='On the event that $G_d$ is singular, define $B^{(d)}$\narbitrarily; the probability of this event tends to zero.'
assert a.count(before)==1
assert a.replace(before,after)==b
oldpdf=PdfReader(old/'main.pdf');newpdf=PdfReader(new/'main.pdf')
assert len(oldpdf.pages)==len(newpdf.pages)==11
changed=[]
for i,(x,y) in enumerate(zip(oldpdf.pages,newpdf.pages),1):
    tx=x.extract_text();ty=y.extract_text()
    if tx!=ty:
        changed.append(i)
        (out/f'page-{i:02d}-text-diff.txt').write_text('\n'.join(difflib.unified_diff(tx.splitlines(),ty.splitlines(),fromfile='previous-pdf',tofile='corrected-pdf')),encoding='utf-8')
result={'manifest_entries':len(checks),'all_hashes_match':True,'source_change_exactly_requested':True,'source_sha256':hashlib.sha256((new/'main.tex').read_bytes()).hexdigest(),'pdf_sha256':hashlib.sha256((new/'main.pdf').read_bytes()).hexdigest(),'pdf_bytes':(new/'main.pdf').stat().st_size,'pdf_pages':len(newpdf.pages),'changed_text_pages':changed,'author_verifier_unchanged':(old/'verify_capacity_cuts.py').read_bytes()==(new/'verify_capacity_cuts.py').read_bytes(),'author_results_unchanged':(old/'finite-checks.json').read_bytes()==(new/'finite-checks.json').read_bytes(),'manifest_checks':checks}
assert changed==[10]
assert result['author_verifier_unchanged'] and result['author_results_unchanged']
(out/'correction-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='manifest_checks'},indent=2))

"""Referee checks: no imports from the author's supplement.

Vertex-subset/ordered-pair enumeration differs from the author's occupation
implementation. Inertia is certified by a Sturm sequence of the characteristic
polynomial, not by the author's congruence routine. Python 3, NetworkX, SymPy.
"""
from pathlib import Path
from itertools import combinations, product
from collections import Counter
from fractions import Fraction
from math import factorial
import hashlib, json, platform, time, zipfile
import networkx as nx
import sympy as sp

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / 'input'
EVIDENCE = ROOT / 'evidence'
START = time.time()
out = {'method': __doc__, 'python': platform.python_version(),
       'networkx': nx.__version__, 'sympy': sp.__version__, 'checks': []}

def emit(kind, **kwargs):
    row = dict(kind=kind, **kwargs)
    out['checks'].append(row)
    print(json.dumps(row), flush=True)

def maximum_sets(g):
    for k in range(len(g), -1, -1):
        sets = [frozenset(c) for c in combinations(g.nodes, k)
                if all(not g.has_edge(u,v) for u,v in combinations(c,2))]
        if sets:
            return k, sets

def blowup(f, s):
    g = nx.Graph()
    g.add_nodes_from((v,j) for v in f for j in range(s))
    g.add_edges_from((u,v) for u,v in combinations(g.nodes,2)
                     if u[0] == v[0] or f.has_edge(u[0],v[0]))
    return nx.convert_node_labels_to_integers(g, ordering='default')

def ground_check(f, s, name):
    alpha, sets = maximum_sets(f)
    assert all(sum(f.has_edge(u,v) for v in I)>=2
               for I in sets for u in f if u not in I)
    g = blowup(f,s)
    n, h = len(g), alpha*s-1
    edges = list(g.edges)
    best, ground = 10**12, []
    for sub in combinations(range(n),h):
        S = frozenset(sub)
        e = sum(u in S and v in S for u,v in edges)
        if e < best: best, ground = e, []
        if e == best: ground.append(S)
    expected = set()
    for I in sets:
        full = {s*v+j for v in I for j in range(s)}
        for v in I:
            for j in range(s): expected.add(frozenset(full-{s*v+j}))
    assert set(ground) == expected
    assert best == (alpha-1)*s*(s-1)//2 + (s-1)*(s-2)//2
    L = [[0]*(h+2) for _ in range(h+2)]
    for S in ground:
        outside = set(g)-S
        r = {u:len(set(g[u]) & S) for u in outside}
        for u in outside:
            for v in outside-{u}:
                x,y = r[u],r[v]
                L[x][y] += 1
                if g.has_edge(u,v):
                    L[x][y] -= 1
                    L[x+1][y] += 1
                    L[x][y+1] += 1
                    L[x+1][y+1] -= 1
    nd = Counter(sum(f.has_edge(u,v) for v in I)
                 for I in sets for u in f if u not in I)
    d = min(nd)
    A = [s-1,s,d*s-1,d*s]
    assert [j for j,row in enumerate(L) if any(row)][:4] == A
    M = sp.Matrix(L).extract(A,A)
    expected_B = s*s*nd[d]*sp.Matrix([[0,alpha],[d,-d]])
    assert M[:2,:2] == sp.zeros(2) and M[:2,2:] == expected_B
    assert M.det() == s**8*alpha**2*d**2*nd[d]**4
    return dict(name=name, base_n=len(f), s=s, n=n, h=h,
                vertex_subsets_tested=int(sp.binomial(n,h)), ground_subsets=len(ground),
                min_edges=best, d0=d, first_four_profiles=A,
                initial_block=[list(map(str,row)) for row in M.tolist()])

def sturm_inertia(M):
    """Exact root counts from a real symmetric matrix's characteristic polynomial."""
    x = sp.Symbol('x')
    p = M.charpoly(x).as_poly()
    zero = 0
    while p.eval(0) == 0:
        p = sp.div(p,sp.Poly(x,x))[0]
        zero += 1
    seq = [sp.Poly(t,x) for t in sp.sturm(p.as_expr(), x)]
    def variations(signs):
        nz = [s for s in signs if s]
        return sum(a != b for a,b in zip(nz,nz[1:]))
    neg_inf = [int(sp.sign(q.LC()))*(-1)**q.degree() for q in seq]
    at_zero = [int(sp.sign(q.eval(0))) for q in seq]
    pos_inf = [int(sp.sign(q.LC())) for q in seq]
    counts = [variations(at_zero)-variations(pos_inf),
              variations(neg_inf)-variations(at_zero), zero]
    assert sum(counts) == M.rows  # also rules out repeated nonzero roots here
    return counts, dict(charpoly_coefficients=list(map(str,M.charpoly(x).all_coeffs())),
                        sturm_degrees=[q.degree() for q in seq],
                        signs_at_negative_infinity=neg_inf, signs_at_zero=at_zero,
                        signs_at_positive_infinity=pos_inf)

def direct_witness(row):
    f = nx.Graph()
    f.add_nodes_from(range(row['base_vertices']))
    f.add_edges_from(row['base_edges'])
    g = blowup(f,row['s'])
    n,m,h = len(g),g.number_of_edges(),row['h']
    # At each individual vertex subset, count ordered remaining pairs.
    # Integer powers use common denominator 1024**m for all graph edges.
    atoms = Counter()
    for sub in combinations(range(n),h):
        S = set(sub)
        outside = set(g)-S
        e = sum(u in S and v in S for u,v in g.edges)
        r = {u:len(set(g[u]) & S) for u in outside}
        for u in outside:
            for v in outside-{u}:
                atoms[e,r[u],r[v],int(g.has_edge(u,v))] += 1
    a = [-31,0,-28,-24,-20,-16]
    D = 32**2
    H = sp.zeros(4)
    for i in range(4):
        for j in range(4):
            total = 0
            for (e,r,t,b),count in atoms.items():
                total += count*(D-a[0]**2)**e*(D-a[0]*a[i+2])**r*(D-a[0]*a[j+2])**t*(D-a[i+2]*a[j+2])**b*D**(m-e-r-t-b)
            H[i,j] = sp.Rational(total,D**m)
    expected = sp.Matrix([[sp.Rational(x) for x in rr] for rr in row['positive_hessian_matrix']])
    assert H == expected
    den = sp.ilcm(*[v.q for v in H])
    integer_H = H*den
    counts,cert = sturm_inertia(integer_H)
    assert counts == [2,2,0]
    return dict(name=row['name'], subset_count=int(sp.binomial(n,h)),
                matrix_exactly_matches_author=True, inertia=counts,
                integer_scale=str(den), sturm_certificate=cert)

def hessian_from_full_polynomial(g,a,h):
    q,n = len(a),len(g)
    result = sp.zeros(q)
    for sig in product(range(q),repeat=n):
        counts = [sig.count(i) for i in range(q)]
        if counts[0]<h or counts[1]<n-h-2: continue
        rem = counts.copy(); rem[0]-=h; rem[1]-=n-h-2
        spins = [i for i,c in enumerate(rem) for _ in range(c)]
        i,j = spins
        weight = sp.prod(1-a[sig[u]]*a[sig[v]] for u,v in g.edges)
        val = weight*sp.prod(factorial(c) for c in counts)
        result[i,j] += val
        if i!=j: result[j,i] += val
    return result

def hessian_from_Q(g,a,h):
    n,q = len(g),len(a)
    ell=a[0]; theta=ell**2
    M=sp.zeros(h+2)
    for sub in combinations(range(n),h):
        S=set(sub); outside=set(g)-S
        e=sum(u in S and v in S for u,v in g.edges)
        r={u:len(set(g[u]) & S) for u in outside}
        for u in outside:
            for v in outside-{u}:
                x,y=r[u],r[v]
                M[x,y] += (1-theta)**e*theta
                if g.has_edge(u,v):
                    for dx,dy,sgn in [(0,0,-1),(1,0,1),(0,1,1),(1,1,-1)]:
                        M[x+dx,y+dy] += (1-theta)**e*sgn
    U=sp.Matrix([[(1-ell*z)**r for r in range(h+2)] for z in a])
    return factorial(h)*factorial(n-h-2)/theta*U*M*U.T

# Integrity and archive identity.
manifest=json.loads((INPUT/'supplement/manifest.json').read_text())
for row in manifest['files']:
    p=INPUT/'supplement'/row['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
with zipfile.ZipFile(INPUT/'supplement.zip') as z:
    for name in z.namelist():
        if name.endswith('/'):continue
        candidate=INPUT/'supplement'/name
        if not candidate.exists() and name.startswith('supplement/'):
            candidate=INPUT/name
        assert candidate.exists(),name
        assert z.read(name)==candidate.read_bytes(),name
emit('integrity',status='PASS',manifest_entries=len(manifest['files']))

# Fully independent pin-spin factorial check, including h=0 and h=n-2.
a=list(map(sp.Rational,['-2/3','0','1/5','3/4']))
identity_count=0
for name,g in [('edge',nx.path_graph(2)),('path3',nx.path_graph(3)),
               ('path4',nx.path_graph(4)),('complete4',nx.complete_graph(4)),
               ('empty4',nx.empty_graph(4)),('cycle4',nx.cycle_graph(4))]:
    for h in range(len(g)-1):
        assert hessian_from_full_polynomial(g,a,h)==hessian_from_Q(g,a,h),(name,h)
        identity_count+=1
emit('full_spin_polynomial_vs_Q',status='PASS',graph_h_cases=identity_count,
     target_nodes=list(map(str,a)),full_hessian_dimension=4)

# All small stable bases, checked on actual blowup vertices.
small=[]
for idx,f in enumerate(nx.graph_atlas_g()):
    if not 3<=len(f)<=5 or not nx.is_connected(f):continue
    alpha,sets=maximum_sets(f)
    if not all(sum(f.has_edge(u,v) for v in I)>=2 for I in sets for u in f if u not in I):continue
    small.append(ground_check(f,2,f'atlas-{idx}'))
emit('vertex_subset_ground_census',status='PASS',cases=len(small),records=small)

# Values beyond the author's s=2,3 census and larger d0.
extra=[]
for name,f,s in [('path3-s4',nx.path_graph(3),4),('path3-s5',nx.path_graph(3),5),
                 ('K33-s3',nx.complete_bipartite_graph(3,3),3),
                 ('K44-s2',nx.complete_bipartite_graph(4,4),2)]:
    extra.append(ground_check(f,s,name))
emit('extended_vertex_subset_cases',status='PASS',records=extra)

examples=json.loads((INPUT/'supplement/results/six-spin-positive-examples.json').read_text())
for row in examples['rows']:
    emit('direct_vertex_pair_witness',status='PASS',**direct_witness(row))

# Negative control: deleting the stability hypothesis makes Lemma 4 false.
f=nx.path_graph(4);s=2;g=blowup(f,s);alpha,sets=maximum_sets(f);h=alpha*s-1
counts=Counter()
for sub in combinations(range(len(g)),h):
    S=set(sub);e=sum(u in S and v in S for u,v in g.edges)
    counts[e]+=1
best=min(counts)
expected=set()
for I in sets:
    full={s*v+j for v in I for j in range(s)}
    for v in full:expected.add(frozenset(full-{v}))
extra_ground=[]
for sub in combinations(range(len(g)),h):
    S=frozenset(sub)
    if sum(u in S and v in S for u,v in g.edges)==best and S not in expected:
        extra_ground.append(sorted(S))
assert extra_ground
emit('negative_control_unstable_P4',status='EXPECTED_FAILURE_OF_GROUND_CLASSIFICATION',
     minimum_edges=best,actual_ground_subsets=counts[best],
     predicted_by_stable_formula=len(expected),additional_ground_subsets=extra_ground)

out['elapsed_seconds']=time.time()-START
out['status']='ALL_REQUESTED_CHECKS_PASSED'
(EVIDENCE/'independent-results.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('PASS independent checks; seconds',out['elapsed_seconds'],flush=True)

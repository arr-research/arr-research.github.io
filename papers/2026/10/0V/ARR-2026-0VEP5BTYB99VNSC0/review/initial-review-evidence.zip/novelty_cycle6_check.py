import networkx as nx,sympy as sp,json
from pathlib import Path
from itertools import combinations
f=nx.cycle_graph(6)
g=nx.convert_node_labels_to_integers(nx.lexicographic_product(f,nx.complete_graph(2)))
N={v:set(g[v]) for v in g}
def alpha(vertices):
 for k in range(len(vertices),-1,-1):
  if any(all(not g.has_edge(u,v) for u,v in combinations(I,2)) for I in combinations(vertices,k)): return k
b=max(alpha(N[u]-{v}) for u,v in list(g.edges)+[(v,u) for u,v in g.edges])
c=max(alpha(N[u]&N[v]) for u,v in g.edges)
res={'graph':'C6[K2]','n':len(g),'degree':5,'common_neighbor_counts':sorted({len(N[u]&N[v]) for u,v in g.edges}),'b':b,'c':c,'tau':sum(nx.triangles(g).values())*2//len(g),'triangle_threshold_rhs':'8','Th_checks':[]}
for h in range(1,len(g)-1):
 T=sp.zeros(h+1)
 for S0 in combinations(g,h):
  S=set(S0); outside=set(g)-S;r={u:len(N[u]&S) for u in outside}
  for u,v in g.edges:
   if u in outside and v in outside:
    T[r[u],r[v]]+=1;T[r[v],r[u]]+=1
 res['Th_checks'].append({'h':h,'positive_semidefinite':T.is_positive_semidefinite})
print(json.dumps(res,indent=2))
Path(r'C:\Trabajo\airr\2026-10-17_revision-seis-estados\output\evidence\novelty-cycle6-check.json').write_text(json.dumps(res,indent=2))

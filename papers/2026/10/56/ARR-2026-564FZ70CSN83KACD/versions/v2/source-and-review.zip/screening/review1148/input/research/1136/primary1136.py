"""Foreign PDFs remain in memory; persist only hash, URL, version and reading receipt."""
from pathlib import Path
import requests,fitz,hashlib,json,sys,datetime
sys.stdout.reconfigure(encoding="utf-8")
W=Path(__file__).parent
urls={'doeblin':'https://arxiv.org/pdf/2503.22823v3','conditional':'https://arxiv.org/pdf/2608.27171v1','multiway':'https://arxiv.org/pdf/2606.19859v1','cohen':'https://lab.rockefeller.edu/cohenje/assets/file/205CohenIwasaRautuRuskaiSenetaZbaganuRelativeEntropyMappingsStochasticMatricesLAA1993.pdf'}
urls.update(buscemi='https://arxiv.org/pdf/1511.08893v2',orders='https://arxiv.org/pdf/2011.05949v4')
key=sys.argv[1];r=requests.get(urls[key],timeout=60)
receipt={'url':urls[key],'status':r.status_code,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if r.status_code==200:
 b=r.content;doc=fitz.open(stream=b,filetype='pdf');receipt.update(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),pages=len(doc))
 if len(sys.argv)>2 and sys.argv[2]=='find':
  terms=sys.argv[3:];hits=[]
  for i,page in enumerate(doc):
   t=page.get_text()
   found=[x for x in terms if x.casefold() in t.casefold()]
   if found:hits.append({'page':i+1,'terms':found})
  receipt['locator_terms']=terms;print(json.dumps(hits))
 elif len(sys.argv)>2:
  pages=[int(x) for x in sys.argv[2:]];receipt['pages_requested']=pages
  for i in pages:print('\nPAGE',i,'\n',doc[i-1].get_text())
 else:print(json.dumps(receipt))
else:print('HTTP',r.status_code)
(W/('PRIMARY_'+key+'_'+datetime.datetime.now().strftime('%H%M%S%f')+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')

from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
ROOT=Path(__file__).resolve().parent
verification=json.loads((ROOT/'input-verification.json').read_text())
own=json.loads((ROOT/'independent-check-results.json').read_text())
census=json.loads((ROOT/'independent-census-results.json').read_text())
replay=json.loads((ROOT/'author-replay-results.json').read_text())
differences=json.loads((ROOT/'author-replay-exact-differences.json').read_text())
assert own['status']=='PASS_ALL_INDEPENDENT_CHECKS'
assert census['status']=='PASS_ALL_1978_CERTIFICATE_RECONSTRUCTIONS'
assert replay['status']=='PASS_ALL_20_AUTHOR_SCRIPTS'
assert all(r['exit_code']==0 for r in replay['rows'])
assert all(r[0].endswith('/elapsed_seconds') for r in differences)
assert not verification['manifest_errors'] and not verification['zip_comparison_errors']
sources=[
 {'id':'BH','authors':'Branden-Huh','title':'Lorentzian polynomials','url':'https://annals.math.princeton.edu/wp-content/uploads/annals-v192-n3-p04-s.pdf','passages':['Theorem 2.25','Theorem 2.30','Corollary 2.32'],'finding':'Fundamento correcto del criterio de hessianos, caracterizacion con soporte M-convexo y cierre por productos.'},
 {'id':'LOS','authors':'Lee-Oh-Seo','title':'Counting homomorphisms in antiferromagnetic graphs via Lorentzian polynomials','url':'https://arxiv.org/html/2506.13659v2','passages':['Theorem 3.1','Section 7, Conjecture 7.1'],'finding':'Suficiencia de cliques y ejemplos pequenos previos; no son novedades del manuscrito.'},
 {'id':'LS','authors':'Lee-Seo','title':'Antiferromagnetic models are clique-minimizing','url':'https://arxiv.org/html/2608.17920v1','passages':['Section 6'],'finding':'Formulacion conexa de la conjetura verificada; no identificada aqui su resolucion.'},
 {'id':'MMS','authors':'Matherne-Morales-Selover','title':'The Newton polytope and Lorentzian property of chromatic symmetric functions','url':'https://arxiv.org/html/2201.07333v4','passages':['Theorem 1.5'],'finding':'Objetivos de coloracion propia, distintos de la cuantificacion sobre todos los objetivos antiferromagneticos.'},
 {'id':'Zeng','authors':'Xiaojian Zeng','title':'Two-vertex cuts and a Lorentzian obstruction for bistable bipartite graphs','url':'https://raw.githubusercontent.com/ArtificialZeng/AI-Has-Taste/f3ae144b74f238f22c2b84b5283cb14ce912fd33/reproducible_source_code/BigWIN2/BW2-PR20260914-lorentzian_cliques/source/manuscript/main.tex','passages':['Main theorem and target spectrum'],'finding':'Objetivo de rango tres para fuentes bipartitas biestables con corte de dos vertices; formula de conectividad distinta.'},
 {'id':'CK','authors':'Choudhury-Khare','title':'Blowup Polynomials and delta-Matroids of Graphs','url':'https://www.mat.univie.ac.at/~slc/wpapers/FPSAC2022/42.pdf','passages':['Theorem 2.3'],'finding':'Caracterizacion mediante otro polinomio de determinantes de distancias; no absorbe el teorema de particiones de espines.'}
]
assessment={
 'schema_version':'referee-assessment-1.0',
 'status':'completed',
 'language':'es',
 'completed_at_utc':datetime.now(timezone.utc).isoformat(),
 'title':'Rank-two obstructions to Lorentzian graph partition functions',
 'author':'Lluis Eriksson',
 'publication_id':None,
 'artifact':{'pages':21,'pdf_sha256':verification['file_hashes']['main.pdf'],'source_sha256':verification['file_hashes']['main.tex'],'supplement_zip_sha256':verification['file_hashes']['supplement.zip'],'rubric_sha256':verification['file_hashes']['airr-rubric.txt'],'supplement_manifest_entries':48,'supplement_files_including_manifest':49,'all_hashes_verified':True},
 'provenance':{
   'assessment_type':'single-model scientific referee review',
   'requested_model':'gpt-6-astra','requested_reasoning_effort':'xhigh',
   'independently_attested_executed_model':None,'independently_attested_reasoning_effort':None,
   'runtime_attestation_note':'La solicitud especifica modelo y esfuerzo; este informe no proporciona atestacion independiente de su ejecucion.',
   'prior_participation_of_exact_base_model':'unknown',
   'construction_used_codex_assistance':True,
   'fresh_conversation_requested':True,
   'technical_memory_filesystem_runtime_isolation_attested':False,
   'prior_reports_scores_conversations_or_development_files_consulted':False,
   'subagents_used':False,
   'author_operates_airr':True,
   'human_peer_review':False,'formal_proof_assistant_verification':False,'statistical_independence_claimed':False,
   'independence_scope':'Implementacion nueva de comprobaciones y lectura de fuentes primarias. Comparte bibliotecas, formulas, equipo y paquete de datos; no independencia estadistica o institucional.'
 },
 'scores':{
   'ordinary_paper_quality':{'score':8.2,'scale_min':0,'scale_max':10,'rubric':'ordinary paper-quality judgment, separate from AIRR Millennium scale','basis':'Pruebas claras y completas para el alcance enunciado, familias infinitas y excelente reproducibilidad; exposicion repetitiva y resultado general abierto.'},
   'airr_research_importance':{'score':4.60,'scale_min':0,'scale_max':10,'rubric':'ARR-ASSESS-1.0 / AIRR-RATING-1.0, unaltered','public_whole_stars':5,'public_label':'Very good','basis':'Avance especializado sustantivo: criterio de gemelos de grado maximo, familias edge-regular y objetivos fijos. No resuelve la conjetura completa ni demuestra consecuencias amplias que justifiquen los niveles superiores. No es probabilidad de correccion ni promedio de criterios.','millennium_top_anchor_preserved':True}
 },
 'criteria':{
   'correctness_confidence':{'rating':5,'out_of':5,'basis':'Pruebas reconstruidas, extremos y factoriales auditados; calculos exactos propios y reproducidos sin discrepancias materiales.'},
   'rigor_and_completeness':{'rating':5,'out_of':5,'basis':'El alcance demostrado se sostiene con argumentos generales; tratamiento correcto de rango rectangular, perturbaciones y casos degenerados.'},
   'novelty_relative_to_checked_sources':{'rating':4,'out_of':5,'basis':'No se encontro absorcion de los resultados centrales en las seis fuentes primarias examinadas. Prioridad mundial no comprobada.'},
   'significance_if_correct':{'rating':3,'out_of':5,'basis':'Aportacion util a una conjetura especializada y restriccion estructural fuerte sobre posibles contraejemplos; impacto amplio y solucion general no establecidos.'},
   'reproducibility_and_inspectability':{'rating':5,'out_of':5,'basis':'Paquete integro, veinte programas ejecutados, dos censos completos reconstruidos con codigo propio y registros exactos conservados.'}
 },
 'recommendation':{'decision':'accept_after_minor_expository_revisions','spanish':'Aceptar tras ajustes expositivos menores, como contribucion parcial especializada.','mathematical_revision_required':False,'general_conjecture_resolved':False,'full_hierarchy_completeness_established':False,'publication_action_taken':False},
 'mathematical_findings':[
   {'claim':'Rectangular profile identity, Lemma 12','status':'supported','detail':'Factor h!(n-h-2)!/theta correcto; identidad rectangular valida. Inercia transferida solo con rango completo de la evaluacion pertinente.'},
   {'claim':'Small-parameter compression, Lemma 13','status':'supported','detail':'Termino lineal positivo del determinante de compresion; no se usa invertibilidad falsa en ell=0.'},
   {'claim':'Maximum-degree true-twin theorem and edge-regular corollary','status':'supported','detail':'Diagonal hh cero y entrada hj positiva fuerzan T_h indefinido. Un edge-regular conexo con una arista de gemelos verdaderos seria completo.'},
   {'claim':'Neighbourhood-independence gap','status':'supported','detail':'h=c+1 valido, columna h no nula, compresion de frontera con dos direcciones positivas; perturbacion racional dependiente de fuente.'},
   {'claim':'Fixed targets for diamond-free, clique-cluster joins and complete multipartite sources','status':'supported','detail':'Casos h=1 y L=0, determinantes y rangos de Vandermonde generalizados verificados. Objetivos comunes de frontera no se confunden con perturbaciones positivas uniformes.'},
   {'claim':'C5[K2] limitation','status':'supported','detail':'Todos los ocho T_h son PSD; h=3,4,5 a ell=-99/100 tienen inercias (2,3,0),(2,4,0),(2,3,2). El primer termino del extremo h=5 tiene solo una direccion positiva.'},
   {'claim':'Three particular subtargets can have Lorentzian nonclique partitions','status':'supported','detail':'Las 51 derivadas cuadraticas y los intercambios M-convexos se comprobaron exactamente; no prueba minimalidad general de cuatro estados.'}
 ],
 'own_checks':{
   'code_imported_from_author':False,
   'shared_libraries':['SymPy','NetworkX'],
   'symbolic_determinant_identities':8,'rectangular_profile_direct_comparisons':108,'degree_direct_comparisons':8,'fixed_target_direct_comparisons':23,'C5_K2_direct_comparisons':3,
   'atlas_connected_graphs':994,'atlas_noncliques':989,'maximum_degree_own_compressions':817,'gap_boundary_own_compressions':634,'diamondfree_sources':255,'diamondfree_trianglefree':88,'diamondfree_with_triangles':167,'independent_minimum_degree_sources':806,
   'positive_hierarchy_certificate_reconstructions':989,'fixed_four_spin_certificate_reconstructions':989,
   'three_subtarget_all_derivative_checks':51,'three_subtarget_support_exchange_checks':True,
   'stored_witness_parameters_used_as_inputs_for_census_audit':True,
   'results':['independent-check-results.json','independent-census-results.json'],
   'scripts':['independent_checks.py','independent_census_audit.py'],
   'status':'all passed'
 },
 'author_code_reproduction':{
   'programs_run':20,'all_exit_codes_zero':True,'mathematical_results_match_archived':True,
   'only_differences':'Six elapsed_seconds values','difference_count':6,
   'maximum_degree_cases':821,'maximum_degree_direct_identities':819,'cases_beyond_edge_wedge_triangle':244,
   'additional_seeded_graphs':64,'larger_sample_exhaustive':False,
   'original_numeric_exploratory_searches_rerun':False,
   'report':'author-replay-results.json','exact_differences':'author-replay-exact-differences.json',
   'scope_note':'Reproduction of supplied code, not independently authored checking.'
 },
 'visual_review':{'all_pages_rendered':True,'pages_visually_inspected':list(range(1,22)),'material_layout_defects_found':False,'full_tex_read':True},
 'literature':{'primary_sources':sources,'targeted_searches_completed':True,'worldwide_priority_certified':False,'not_checked':['All citing papers','All unindexed preprints and repository notes','Comprehensive worldwide priority']},
 'unresolved_material_mathematical_objections':[],
 'adverse_findings_and_limits':[
   'La conjetura completa de fuentes conexas sigue abierta.',
   'No se demuestra suficiencia de la jerarquia completa; el criterio de parametro pequeno es incompleto.',
   'No se demuestra minimalidad del numero de estados ni uniformidad de perturbaciones positivas para las familias de frontera.',
   'Los censos de 989 grafos y la muestra adicional de 64 no son pruebas para todos los ordenes.',
   'La novedad solo se respalda respecto de las fuentes primarias consultadas; prioridad exhaustiva no establecida.',
   'La exposicion es repetitiva y demora el mecanismo estructural principal.',
   'No hay verificacion formal, revision humana, aislamiento tecnico atestado ni independencia estadistica.',
   'El autor opera AIRR, lo que debe conservarse como informacion de procedencia.'
 ],
 'minor_revision_suggestions':[
   'Adelantar el lema de perfiles y el teorema de grado maximo; reorganizar identidades preliminares.',
   'Anadir tabla comparativa de clases de fuentes, estados y objetivos fijos o dependientes de fuente.',
   'Concentrar detalles extensos del censo en el suplemento preservando los alcances exactos.',
   'Anadir un programa unico de reproduccion y resumen de resultados.',
   'Complementar los tres controles lorentzianos finitos con una descripcion breve de sus soportes.'
 ],
 'service_or_usage_failure':None,
 'report_file':'referee-report.txt','report_sha256':hashlib.sha256((ROOT/'referee-report.txt').read_bytes()).hexdigest()
}
(ROOT/'referee-assessment.json').write_text(json.dumps(assessment,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':assessment['status'],'quality':8.2,'airr_importance':4.6,'report_sha256':assessment['report_sha256']},ensure_ascii=True))

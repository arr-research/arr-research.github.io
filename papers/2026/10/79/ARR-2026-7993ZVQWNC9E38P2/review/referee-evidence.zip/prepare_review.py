from pathlib import Path
import hashlib, json, zipfile, shutil
from PIL import Image, ImageDraw
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent
INP = ROOT.parent / 'input'
manifest = json.loads((INP/'supplement'/'manifest.json').read_text(encoding='utf-8'))
errors=[]
for e in manifest['entries']:
    b=(INP/'supplement'/e['path']).read_bytes()
    if len(b)!=e['bytes'] or hashlib.sha256(b).hexdigest()!=e['sha256']:
        errors.append(e['path'])
with zipfile.ZipFile(INP/'supplement.zip') as z:
    zn=[n for n in z.namelist() if not n.endswith('/')]
    zerrors=[]
    for n in zn:
        p=INP/'supplement'/Path(n).name
        if not p.exists() or p.read_bytes()!=z.read(n):zerrors.append(n)
pdf=PdfReader(INP/'main.pdf')
texts=[p.extract_text() for p in pdf.pages]
(ROOT/'pdf-text-by-page.json').write_text(json.dumps(texts,ensure_ascii=True,indent=2),encoding='utf-8')
for start in range(0,21,3):
    ims=[Image.open(ROOT/'pages'/f'page-{i+1:02}.png').convert('RGB') for i in range(start,min(start+3,21))]
    width=sum(i.width for i in ims)
    contact=Image.new('RGB',(width,max(i.height for i in ims)+24),'#ddd')
    draw=ImageDraw.Draw(contact);x=0
    for j,im in enumerate(ims,start+1):
        contact.paste(im,(x,24));draw.text((x+10,5),f'PAGE {j}',fill='black');x+=im.width
    contact.save(ROOT/'pages'/f'contact-{start//3+1:02}.png')
shutil.copytree(INP/'supplement',ROOT/'author-replay',dirs_exist_ok=True)
out={'file_hashes':{f:hashlib.sha256((INP/f).read_bytes()).hexdigest() for f in ['main.pdf','main.tex','supplement.zip','airr-rubric.txt']},'manifest_entries':len(manifest['entries']),'manifest_errors':errors,'zip_file_count':len(zn),'zip_comparison_errors':zerrors,'extracted_file_count':len(list((INP/'supplement').glob('*'))),'pdf_pages':len(pdf.pages)}
(ROOT/'input-verification.json').write_text(json.dumps(out,ensure_ascii=True,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=True))

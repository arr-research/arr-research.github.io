"""Reproduce supplied exact verifiers in the output copy, never in input."""
from pathlib import Path
import subprocess, sys, json, time, hashlib
ROOT=Path(__file__).resolve().parent
COPY=ROOT/'author-replay'
ORIGINAL=ROOT.parent/'input'/'supplement'
SCRIPTS=[
'verify_degree_kernel.py','verify_regular_obstruction.py',
'verify_parametric_obstruction.py','verify_conditioning_hierarchy.py',
'verify_normalized_target.py','certify_source_witnesses.py',
'certify_profile_hierarchy.py','audit_profile_certificates.py',
'verify_neighbourhood_gap.py','verify_fixed_diamond.py',
'verify_two_clique_extension.py','verify_fixed_five_cluster.py',
'verify_four_spin_restriction.py','verify_multipartite_extension.py',
'verify_maximum_degree_twins.py','probe_zero_parameter_kernels.py',
'verify_blowup_layer.py','probe_fixed_diamond_scope.py',
'probe_larger_fixed_target.py','probe_three_spin_targets.py']
def normalized(v):
    if isinstance(v,dict):return {k:normalized(x) for k,x in v.items() if k not in {'seconds','elapsed_seconds','elapsed','environment'}}
    if isinstance(v,list):return [normalized(x) for x in v]
    return v
report={'kind':'Reproduction of author code, not a fresh implementation','rows':[]}
for script in SCRIPTS:
    start=time.time()
    p=subprocess.run([sys.executable,'-B',str(COPY/script)],cwd=COPY,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (ROOT/(script+'.replay.log')).write_text(p.stdout+'\nSTDERR:\n'+p.stderr,encoding='utf-8')
    row={'script':script,'exit_code':p.returncode,'seconds':round(time.time()-start,3),'script_sha256':hashlib.sha256((COPY/script).read_bytes()).hexdigest()}
    report['rows'].append(row)
    (ROOT/'author-replay-results.json').write_text(json.dumps(report,ensure_ascii=True,indent=2),encoding='utf-8')
    print(json.dumps(row,ensure_ascii=True),flush=True)
    if p.returncode:sys.exit(p.returncode)
comparisons=[]
for f in ORIGINAL.glob('*.json'):
    a=f.read_bytes();b=(COPY/f.name).read_bytes()
    comparisons.append({'file':f.name,'byte_identical':a==b,'content_identical_excluding_runtime_environment':normalized(json.loads(a))==normalized(json.loads(b))})
report['comparisons']=comparisons
report['status']='PASS_ALL_20_AUTHOR_SCRIPTS'
(ROOT/'author-replay-results.json').write_text(json.dumps(report,ensure_ascii=True,indent=2),encoding='utf-8')
print(json.dumps({'status':report['status'],'nonidentical':[r for r in comparisons if not r['byte_identical']]},ensure_ascii=True),flush=True)

# Positive circuit obstructions and rigidity for lattice-fiber log-concavity

Machine-readable extraction of canonical paper.pdf (ten pages), SHA256 5e2d16b335baa02a4aed0cb75c23a28dc2d6762c71e6151cb44eb61dbecaa48c. The PDF governs mathematical layout.

Positive circuit obstructions and rigidity
for lattice-ﬁber log-concavity
Lluis Eriksson
Second-version manuscript, 27 October 2026
Abstract
We characterize the full-row-rank integer matrices whose lattice-point counts satisfy
midpoint log-concavity in every ﬁxed integer coordinate box. Under the promise that all
three integer ﬁbers are nonempty, the property holds exactly for equimodular matrices:
their nonzero maximal minors have one common magnitude. The same classiﬁcation holds
for coeﬃcientwise nonnegativity and positive external ﬁelds. Necessity has an explicit
certiﬁcate: a primitive minimal kernel circuit with a coeﬃcient of magnitude at least two
gives counts (1, 1, 2) in one box, supported on at most r + 1 coordinates. The defect is
one negative monomial, so it violates the inequality at every positive ﬁeld. If empty ﬁbers
are allowed for arbitrary ambient integral right-hand sides, the common minor magnitude
must additionally be odd. Classical circuit and lattice-normalization results supply the
structural tools; suﬃciency uses Leake–Mohammadi Yekta’s coeﬃcientwise inequality. We
also characterize equality through integral translations, using squarefreeness of complete
lattice-point enumerators, and decide it with 6n linear optimizations. The equality result
transfers to equimodular matrices on their column lattice. We retain the rational-box
boundary and distinguish midpoint classiﬁcation from the open global Jensen question.
Finite exact controls and their byte-preserving reproduction supplement accompany the
analytic proofs.
1 Setting and dependence on prior work
Let M ∈ Zr×n have full row rank, with every nonzero maximal minor equal to +1 or −1. This
is the rectangular unimodular convention used here. Fix ﬁnite integer bounds ℓ, u ∈ Zn and
deﬁne
Pb = {x ∈ Rn : Mx = b, ℓ ≤ x ≤ u},
Fb(z) =
∑
x∈Pb∩Zn
zx.
Vector inequalities are coordinatewise; exponents may be negative. We use the ring
Ln = C[z±1
1 , . . . , z ±1
n ].
An external ﬁeld is w ∈ Rn
>0.
For b−, b0, b+ ∈ Zr satisfying b− + b+ = 2b0, the essential input is Leake–Mohammadi
Yekta [1, Theorem 3.1]:
D(z) =Fb0(z)2 − Fb−(z)Fb+(z) has nonnegative coeﬃcients. (1)
Their Lemma 3.4 gives integrality of these box ﬁbers. We use their coeﬃcientwise theorem
directly, not a new proof of that inequality. Equality is distinct from their open global Jensen
question [ 1, Question 1.7].
1

The main addition in this substantive extension of our earlier Working paper [ 9] is a sharp
universal matrix classiﬁcation with an explicit positive circuit obstruction. The equivalence
between equimodularity and unit circuit coeﬃcients, lattice normalization, and recognition
are classical [ 4, 5, 6]; they are not claimed as discoveries here. The possible speciﬁc converse
is a common-box failure with all three counts positive, rather than only an empty central
section. The earlier equality characterization and optimization reduction are retained and
extended by the classical normalization. Scoped source comparison does not certify worldwide
priority. Csikvári–Imolay [ 3] already study equality between Eulerian orientation and half-
graph counts; their pair-decomposition methods are antecedents of the source argument. That
comparison concerns diﬀerent combinatorial objects rather than the three ﬁxed-matrix ﬁbers
here. Tardos’s algorithm [ 2] is an existing optimization tool.
2 A sharp matrix classiﬁcation
In this section only, let A ∈ Zr×n be an arbitrary full-row-rank integer matrix, 1 ≤ r ≤ n; it
is not initially assumed unimodular. Write FA
b for its integer-box ﬁber enumerator. All boxes
have ﬁnite integral endpoints and may ﬁx coordinates. We say that A is equimodular if all its
nonzero maximal minors have the same absolute value D > 0. This is classical terminology;
some sources call this class unimodular without requiring D = 1[5, 6].
The properties below are universal: each is quantiﬁed over every such ﬁxed box and every
triple b−, b0, b+ ∈ Zr with b− + b+ = 2b0. Let C+ mean coeﬃcientwise nonnegativity of
(FA
b0 )2 − FA
b−FA
b+
whenever the three integer-point sets are nonempty. Deﬁne W+ by requiring the numerical
inequality at every positive ﬁeld, and N+ by requiring it at the ﬁeld 1. A merely nonempty
real ﬁber is not this promise.
Theorem 2.1 (Positive-ﬁber classiﬁcation) . For every full-row-rank integer A, the following
are equivalent:
C+, W+, N+, A is equimodular.
If A is not equimodular, a primitive minimal kernel circuit gives a box with at most r + 1
nonﬁxed coordinates and three distinct midpoint right-hand sides with counts (1, 1, 2). Their
coeﬃcient defect is one negative monomial, so the same triple violates the inequality at every
positive ﬁeld.
The equivalence of the three inequalities is at the level of these universal properties. A
numerical inequality for one arbitrary triple is not asserted to imply coeﬃcientwise nonnega-
tivity. The suﬃciency below is a classical normalization followed by the external inequality ( 1).
The possible additional observation is the necessity with an explicit all-positive count witness,
rather than a central lattice hole alone.
Lemma 2.2(Classical circuit criterion) . A full-row-rank integer matrix is equimodular if and
only if every primitive minimal kernel circuit has all its nonzero coeﬃcients in {1, −1}.
Proof. The statement is recorded explicitly in [ 5, Deﬁnition 1.1(2)–(3)]; we recall the elemen-
tary argument to ﬁx conventions. A circuit is a nonzero integer kernel vector of minimal
support, with relatively prime nonzero coeﬃcients. Its support S has size at most r + 1, and
the restricted real kernel is one-dimensional.
If all nonzero maximal minors have absolute value D, extend S\{j} to a column basis. The
resulting fundamental circuit has support S; Cramer’s rule expresses its nonzero coeﬃcient
ratios as ratios of nonzero maximal minors. Their absolute values are one, and primitive
2

scaling gives coeﬃcients ±1. A zero column has a singleton circuit with primitive coeﬃcient
one.
Conversely, connect two column bases I, J by exchanges. For j ∈ J \ I, its fundamental
circuit in I ∪ { j} contains an i ∈ I \ J, since otherwise J would contain a dependence.
Exchanging i for j increases the intersection with J. The determinant ratio of the two bases
is the corresponding circuit-coeﬃcient ratio, hence has absolute value one. Iteration proves
equimodularity. This is a classical characterization, not a new recognition theorem.
Lemma 2.3(A positive circuit certiﬁcate) . Let c be a primitive minimal integer kernel circuit
of A, oriented so that ci = a ≥ 2. Put p = c+, q = c−, and use the box 0 ≤ x ≤ |c|, ﬁxing all
coordinates outside its support to zero. For the column Ai, set
Rk = Ap − kAi (k = 0, 1, 2).
Then
FA
R0 = zp + zq, F A
R1 = zp−ei , F A
R2 = zp−2ei ,
and consequently
(FA
R1)2 − FA
R2FA
R0 = −z|c|−2ei . (2)
Proof. The point xk = p − kei lies in the box for each k. Every other integer solution on the
circuit support is xk + tc, with t ∈ Z: the real kernel is Rc, and a Bezout combination of the
coeﬃcients of the primitive c shows that tc ∈ Zn forces t ∈ Z.
The i-th coordinate imposes −1 +k/a ≤ t ≤ k/a. There is another support coordinate
j ̸= i, since a primitive singleton circuit cannot have coeﬃcient of magnitude at least two. Its
bound imposes −1 ≤ t ≤ 0, regardless of the sign of cj. Together the bounds give
−1 +k/a ≤ t ≤ 0.
For k = 0 the admissible integers are −1, 0, yielding q, p; for k = 1, 2, the only one is zero.
This includes a = 2, uniform-sign circuits and circuits with no coeﬃcient of magnitude one.
The displayed enumerators and defect follow. The exponent |c| − 2ei is nonnegative. Finally
Ai ̸= 0, since a zero column would be a smaller singleton dependence, so the three right-hand
sides are distinct.
Proof of Theorem 2.1. The implications C+ ⇒ W+ ⇒ N+ are immediate. If A is not equimod-
ular, Lemma 2.2 supplies the circuit in Lemma 2.3. The midpoint triple (R2, R1, R0) has
positive counts (1, 1, 2), contradicting N+. Its support has size at most r + 1, and ( 2) gives
the stronger ﬁeld-independent failure.
For suﬃciency, choose a nonsingular column basis B of an equimodular A, with | det B| =
D. Cramer’s rule gives C = B−1A ∈ Zr×n, with entries 0, ±1 and maximal minors 0, ±1.
Since C contains an identity column basis,
AZn = BZr. (3)
Each nonempty integer ﬁber has bs = Axs for an integer xs, and therefore B−1bs = Cxs ∈ Zr.
The transformed integral right-hand sides retain their midpoint relation. The transformation
changes only row equations, preserving the exact real and integer ﬁbers, box and original
coordinate ﬁelds. Apply Leake–Mohammadi Yekta’s coeﬃcientwise Theorem 3.1 to C. This
proves C+. The normalization and lattice identity are classical [ 6, Theorem 3]; B−1 itself need
not be integral.
Theorem 2.4 (Ambient lattice and parity) . Remove the promise that all three integer ﬁbers
are nonempty. Then each universal inequality holds if and only if A is equimodular and its
common nonzero maximal-minor magnitude D is odd. For equimodular even D, a binary box
with at most r nonﬁxed coordinates gives midpoint counts (1, 0, 1).
3

Proof. Necessity of equimodularity follows from Theorem 2.1. If D is even, a column basis B
is singular modulo two. Choose nonzero α ∈ {0, 1}r with Bα even. On those basis coordinates
take the box [0, α], ﬁxing the others to zero. Invertibility of B makes the extreme ﬁbers at
0, Bα the singletons 0, α. The integral midpoint right-hand side Bα/2 has the unique real
solution α/2, which is not integral. This gives the claimed failure.
Now suppose D is odd. If an endpoint enumerator is zero, the coeﬃcientwise inequality is
immediate. Otherwise b−, b+ ∈ BZr by ( 3). For v = B−1b0, both 2v and Dv are integral, the
latter by the adjugate formula. Bezout’s identity for 2, D makes v integral. All transformed
right-hand sides are integral, so the same external theorem for C proves coeﬃcientwise non-
negativity, including the initially possibly empty central ﬁber. Numerical versions follow as
before.
Corollary 2.5(Parity-halving formulation). The unconditional universal inequalities in The-
orem 2.4 are equivalent to: for every α ∈ { 0, 1}n with Aα ∈ 2Zr, there is an integer β with
0 ≤ β ≤ α and 2Aβ = Aα.
Proof. The unconditional inequality applied to [0, α] forces a nonempty integer central ﬁber
because both endpoints are nonempty. Conversely, for a bad primitive circuit c, let α be its
coordinatewise residue modulo two. It is nonzero and Aα is even. A hypothetical β gives
the nonzero kernel vector d = 2β − α with support contained in that of c and nonzero entries
±1. Minimal support and the one-dimensional kernel force proportionality; primitivity would
then make every nonzero coeﬃcient of c have magnitude one, a contradiction. Thus A is
equimodular. The even-basis construction above excludes even D, and Theorem 2.4 ﬁnishes
the proof.
This feasibility formulation is close to the existing proof, not a separate new geometric
class. For example write ℓ + u = 2h + α, with h ∈ Zn and binary α. If A(ℓ + u) is even, the
criterion supplies h + β in the box with image A(ℓ + u)/2; this is the central existence step
used in [ 1, Lemma 3.3].
Equality and algorithm transfer. For equimodular A and three nonempty integer ﬁbers,
the same normalization transfers Theorem 4.1 and Theorem 5.1 below without changing poly-
topes or ﬁelds. Their equality characterization and 6n linear-optimization decision therefore
apply on the column lattice. This is an application of the classical row normalization; it does
not provide a new equimodularity recognition algorithm or remove regular kernel geometry.
A limit, not a Jensen solution. The odd-index extension is speciﬁc to midpoints. For
A = [3], the ﬁbers at right-hand sides 0, 3 in [0, 1] have count one, while their mean with
weights 2/3, 1/3 is the integral right-hand side 1, whose count is zero. The same counts hold
for unbounded nonnegative ﬁbers of this matrix. This matrix is not unimodular in the D = 1
convention of the open question; it does not answer [ 1, Question 1.7].
3 Squarefreeness and multiplicative rigidity
For a nonempty lattice polytope P, let EP (z) = ∑
a∈P ∩Zn za. All lattice points, including
boundary points, occur with coeﬃcient one. Squarefree means no repeated nonunit irreducible
factor in Ln. Laurent monomials are units.
Lemma 3.1. If polytopes Q, R are given and e is an edge of Q, there is a functional v such
that Qv = e, Rv is a vertex or an edge parallel to e, and (2Q + R)v is an edge. Superscripts
denote maximizing faces.
4

Proof. Work in the direction space of Q + R, of dimension d, translating the summands. The
normal cone of e has dimension d − 1. Choose v in its relative interior. Exclude normal cones
of faces of R of dimension at least two; they have dimension at most d − 2. Also exclude
intersections with normal cones of edges f not parallel to e: these lie in e⊥ ∩ f⊥, again of
dimension at most d − 2. Finitely many such sets cannot cover the relative interior of the
edge cone. The remaining face Rv is a vertex or a parallel edge. Maximizing faces commute
with Minkowski addition. For d = 1, use the zero functional: the nonpoint summands are
parallel segments. Passing to the direction space removes common normal lineality and covers
lower-dimensional polytopes.
Newton polytopes of products and face-factor methods are classical. Abu Salem–Gao–
Lauder [ 7] use edge polynomials in polyhedral factorization algorithms. Averkov–Langfeld [ 8,
Section 2 and Problem 2.3] study lattice-set enumerators and Laurent/group-ring factorization
in covariogram reconstruction. Our use of complete coeﬃcient-one support forces a square-
free edge polynomial; no origin claim for the Newton-face mechanism, worldwide priority
certiﬁcate, or general reconstruction theorem is intended.
Theorem 3.2. The complete lattice-point enumerator EP of any nonempty lattice polytope
is squarefree in Ln.
Proof. A point gives a unit. Suppose otherwise that EP = G2H, with G a nonunit Laurent
polynomial. Newton polytopes satisfy P = 2Q + R, where Q = Newt(G) and R = Newt(H).
The nonunit G has at least two exponent vectors, so Q has an edge e. Lemma 3.1 gives a
functional whose face in P is the edge 2e + Rv. Let a be an endpoint and q ∈ Zn its primitive
integer direction. The lattice points of that edge are exactly a, a + q, . . . , a + mq for an integer
m ≥ 1. Its face polynomial is
inv(EP ) =za(1 +t + · · · + tm), t = zq.
Face products also give inv(EP ) = inv(G)2 inv(H). Up to a Laurent monomial, inv(G) is a
nonconstant polynomial g(t) with nonzero constant coeﬃcient: its edge endpoint terms are
present. Thus g(t)2 divides 1 + t + · · · + tm in C[t±1]. But (tm+1 − 1)/(t − 1) has only
simple nonzero roots in characteristic zero, a contradiction. The primitive direction makes
the univariate edge Laurent representation injective.
Both complete support and coeﬃcient one matter. For instance,
1 +x + x3 + x4 = (1 +x)2(1 − x + x2)
omits the lattice point 2 of its Newton segment and has a repeated factor, despite having
only zero or one coeﬃcients. The full-support polynomial (1 +x)2 instead has a coeﬃcient
diﬀerent from one. Theorem 3.2 is not a statement about Ehrhart or h∗-polynomials.
Theorem 3.3 (Multiplicative rigidity) . For nonempty lattice polytopes P1, . . . , Pk, Q and
k ≥ 2,
k∏
i=1
EPi = Ek
Q
if and only if Pi = Q + hi for integral vectors hi with ∑
i hi = 0.
Proof. The Laurent ring is a unique factorization domain. Every irreducible factor of EQ has
multiplicity k on the right. Each of the k squarefree enumerators on the left contributes at
most once, so every one contributes once. No other factor can appear. Hence EPi = cizhi EQ.
Coeﬃcient one forces ci = 1. Supports and then convex hulls give Pi = Q + hi; cancellation
gives ∑
i hi = 0. Monomial enumerators cause no exception. The converse follows directly
from translation.
5

4 The equality characterization
Theorem 4.1. In the setting of Section 1, suppose the three ﬁbers are nonempty. The fol-
lowing are equivalent:
1. Fb0(w)2 = Fb−(w)Fb+(w) for some w ∈ Rn
>0;
2. F2
b0 = Fb−Fb+ as Laurent polynomials;
3. for an h ∈ Zn, Pb+ = Pb0 + h and Pb− = Pb0 − h.
Equality therefore holds at every positive ﬁeld or the inequality is strict at every positive ﬁeld.
Proof. A nonzero Laurent polynomial with nonnegative coeﬃcients evaluates positively at
every positive ﬁeld. Thus ( 1) proves 1 ⇒ 2.
Each box ﬁber is a lattice polytope. Indeed, at a vertex select n − r independent active
coordinate constraints complementary to the row equations. These coordinates are at integer
bounds. The remaining coordinates solve a system with a nonsingular r-column submatrix of
M, of determinant ±1; they are integers. Boundedness now gives Pb = conv(Pb ∩ Zn).
Apply Theorem 3.3 with k = 2to obtain 2 ⇒ 3. Translations give the polynomial identity
and equality at every positive ﬁeld. If equality fails, the nonzero defect in ( 1) is positive at
every such ﬁeld.
Corollary 4.2. Unweighted equality for three nonempty ﬁbers forces their three lattice-point
counts to be equal.
Proof. Use Theorem 4.1 at w = 1; integral translation preserves lattice-point counts.
Thus a nonconstant geometric progression of three counts cannot be an equality case.
Positive ﬁelds are essential. With negative Laurent exponents, evaluation at a zero coordinate
can be undeﬁned; when all exponents are nonnegative, zero weights can erase a nonzero
coeﬃcient defect.
Equality need not mean singleton ﬁbers. For M = [1 0], box [0, 2]2, and RHS 0, 1, 2, each
ﬁber has three lattice points and Fb(z) =zb
1(1 +z2 + z2
2). The ﬁbers are symmetric translates,
so equality holds in every positive ﬁeld; the three weighted values need not themselves coincide.
5 An equality algorithm using linear optimization
Let ms,i and Us,i be the minimum and maximum of coordinate i on Pbs , for s = −, 0, +. These
extrema are integers.
Theorem 5.1. Equality can be decided by 6n linear optimizations without evaluating any
lattice-point count. Set h = m+ − m0. The decision is equality precisely when
Mh = b+ − b0, U + = U0 + h, m − = m0 − h, U − = U0 − h. (4)
Under the integer-input and nonempty-unimodular promises above, the decision admits a
strongly polynomial number of rational arithmetic operations, with intermediate encoding
lengths polynomial in total input length.
Proof. The eﬀective bounds describe each ﬁber exactly:
Pbs = {x : Mx = bs, m s ≤ x ≤ Us}.
One inclusion is the deﬁnition of the extrema; the other uses ms ≥ ℓ and Us ≤ u. Translation
must shift every minimum and maximum by the same vector, uniquely ﬁxing h = m+ − m0.
6

The exact eﬀective-box descriptions show that ( 4) is necessary and suﬃcient for the two
symmetric translations. Here b− − b0 = −(b+ − b0). Apply Theorem 4.1.
For the complexity bound select a nonsingular column basis B of M. By Cramer’s rule
every entry of A = B−1M is in {0, ±1}: each numerator is a maximal minor and det B =
±1. Basis selection, inversion and RHS transformation take polynomially many rational
arithmetic operations with polynomial intermediate encoding lengths. Replace Mx = bs
by Ax = B−1bs. The inequality matrix [A; −A; I; −I] has constant-sized entries. Tardos’s
theorem [2] bounds the number of arithmetic operations polynomially in this matrix’s encoding
length, independently of the RHS and objective encodings. That length is polynomial in r, n.
Apply it to the 6n coordinate optimizations and then perform the tests. This is the strongly
polynomial arithmetic model, not a bit-time claim independent of input lengths.
The ﬁeld w need not be an algorithm input: the decision applies simultaneously to all
positive ﬁelds. We promise nonempty ﬁbers and unimodularity rather than claiming a new
recognition algorithm. Standard exact primal–dual LP certiﬁcates can verify the extrema
and comparisons without enumerating lattice points or expanding the defect polynomial. The
ﬁnite controls below do not implement Tardos’s algorithm.
6 Strictness and the boundary of the hypotheses
Corollary 6.1. For an integer box with ui −ℓi ≤ 1, distinct feasible endpoint right-hand sides
with integral midpoint have strict midpoint inequality at every positive ﬁeld.
Proof. Equality would provide an integer central point x and an integral h with x−h, x, x + h
all in the same box. Thus 2|hi| ≤ 1, forcing h = 0and equal endpoint right-hand sides.
Corollary 6.2. Let P = {x ≥ 0 : Mx = b} be nonempty and bounded for integral b and
full-row-rank unimodular M. If d = dimP > 0, then for all integers t ≥ 1,
|tP ∩ Zn|2 > |(t − 1)P ∩ Zn| |(t + 1)P ∩ Zn|.
For a point P, all these counts are one.
Proof. Boundedness and nonemptiness make the nonnegative recession cone {x ≥ 0 :Mx = 0}
equal to {0}. Hence the ﬁber at RHS tb is tP, also for t = 0. For any ﬁxed t, choose a common
ﬁnite integer box containing the three scaled polytopes. Equality would make tP and (t+1)P
translates by Theorem 4.1. Their relative volumes are td and (t + 1)d times the positive
relative volume of P, which diﬀer when d > 0. Integrality handles the point case. The weak
inequality is already [ 1, Corollary 3.5].
The translation claim is false for arbitrary rational real ﬁbers. Take M = [1 1], bounds
0 ≤ x ≤ 1/2, 0 ≤ y ≤ 2, and RHS 0, 1, 2. The integer-point enumerators are 1, zy, z2
y,
satisfying equality identically. The ﬁrst real ﬁber is a point; the other two are segments. They
cannot be symmetric translates. This counterexample arose in component review and refutes
an ambiguous rational-input extension in our original memo.
For ﬁnite rational bounds a diﬀerent, valid interface is to round them ﬁrst to ⌈ℓ⌉, ⌊u⌋.
Integer-point sets are unchanged, and the theorem concerns the rounded ﬁbers, not the original
real ones. Use feasibility LPs to handle empty rounded ﬁbers. If the central ﬁber is empty,
both endpoints cannot be nonempty: their average would make the integral central polytope
nonempty. Equality is then 0 = 0. If the center is nonempty and an endpoint is empty,
the inequality is strict. Otherwise use Theorem 5.1. This gives a polynomial bit-complexity
decision for ﬁnite rational boxes. Rational rounding is not included in our strongly polynomial
arithmetic assertion for integer input.
7

7 A variable-wise log-concave array excluded by rigidity
Deﬁne f on {−1, 0, 1}2, with rows indexed by the ﬁrst coordinate, by
(f(i, j)) =


6/5 5 /6 1 /10
5/6 1 6 /5
1/10 6 /5 5 /6

, p (x, y) =
1∑
i,j=−1
f(i, j)xiyj.
It satisﬁes variable-wise log-concavity [ 1, Deﬁnition 2.1]. Each coeﬃcient slice is log-concave
without internal zeros. After y = t > 0, let A−, A0, A+ be the three coeﬃcients in x. Exactly,
900t2(A2
0 − A−A+) = 517 + 129t + 891t2 + 1427t3 + 1221t4 > 0.
Symmetry handles evaluations of x; extractions outside the support are zero, as allowed by
the source convention.
The points v1 = (−1, −1), v2 = (1, 0), v3 = (0, 1) have mean zero and coeﬃcients 6/5 >
f(0) = 1. Thus this class alone does not imply global Jensen. The distinction between line
and global concavity is already explicit in [ 1]; that distinction is not a new discovery claimed
here.
Proposition 7.1. The exact array cannot be the weighted counts at one positive ﬁeld of a
single ﬁxed integer-box unimodular family whose right-hand sides depend aﬃnely on the two
array indices, even after common positive scaling and exponential output rescaling.
Proof. For each i, f(vi)f(−vi) =f(0)2 = 1. Theorem 4.1 would therefore give Pvi = P0 + hi
and P−vi = P0 −hi for integral shifts. The RHS parametrization may be aﬃne, with auxiliary
RHS coordinates ﬁxed; it must preserve the indicated barycenters.
By convexity of the common box and linearity of the constraints,
Pv1 + Pv2 + Pv3
3 = P0 + h1 + h2 + h3
3 ⊆ P0.
A bounded nonempty polytope cannot contain a nonzero translate of itself: maximize the
functional in that translation direction. Thus ∑
i hi = 0. The corresponding enumerator
translations imply ∏
i Fvi (w) = F0(w)3, contradicting (6/5)3 > 1. Common scaling and
exponential output rescaling cancel at these barycenters.
This excludes the exact array, not nearby strictly perturbed arrays, and does not answer
the global Jensen question for unimodular ﬁbers.
8 Controls, review context and limitations
Six explicitly supplied unimodular matrices, in boxes of widths one, two and three, gave 1,160
nontrivial midpoint triples. All nonzero maximal minors were checked. Polynomial equality,
symmetric support translation and the extrema criterion agreed in all cases, including 72
equalities. All coeﬃcient defects were nonnegative. These ﬁnite enumerations are controls,
not a general proof or an LP implementation.
A separate exact rational-polynomial check covered all 213 distinct lattice polytopes with
vertices in {0, 1, 2}2: nine points, 36 segments and 168 polygons. After clearing monomial
units, the gcd with the two partial derivatives was constant in every case. The nonsaturated
negative control 1+x+x3+x4 gave gcd x+1 with its derivative. This supplies ﬁnite arithmetic
checks, not higher-dimensional or proof-assistant veriﬁcation.
8

Model assessments and review context
The original component audits822/824 examined the rational-array calculation and equality
argument. Audit824 required the integer-box restriction and refuted an extension to the
original rational real ﬁbers; the counterexample remains explicit above. A full assessment of
the unchanged earlier version [ 9] examined its remaining rounded-ﬁber, strictness and ﬁnite-
polytope claims. Its report belongs to that earlier exact PDF and is not a grade for this
extension.
The new classiﬁcation proof was examined in one fresh component audit840, which received
its frozen proof and controls without prior reports or numeric targets. It found no invalidating
mathematical defect, conditional on the cited LMY inequality, and explicitly identiﬁed the
classical circuit/normalization antecedents. It did not assign a manuscript score or certify pri-
ority. The positive negative-monomial identity was also checked. Context isolation, eﬀective
model identity and independence are not attested.
The immutable reproduction supplement contains the original controls839/840, their na-
tive hashes and expected outputs, and a wrapper that runs copies without changing frozen
evidence. It reproduces every mathematical result ﬁeld and the byte hash of all 16,828 positive
certiﬁcates; declared UTC and elapsed ﬁelds naturally diﬀer. The controls additionally cover
127,608 nonempty coeﬃcientwise triples and 46,362 binary centers. They are ﬁnite falsiﬁca-
tion checks, not the proof of the universal theorem. The observed successful reproduction used
Python3.12.14 and SymPy1.14.0. The source bundle accompanying this manuscript contains
the same supplement and command instructions. Earlier equality controls are preserved in
the immutable ﬁrst-version evidence .
At the time this second-version draft was prepared, no full assessment of its exact combined
PDF had been obtained. Any later importance score must accompany its complete report,
objections and context and bind this new exact PDF. No earlier version’s score or component
audit can substitute for that assessment.
AI and responsibility disclosure.The named author directed substantial OpenAI Codex
assistance in derivation, writing and numerical work. GPT-6 Astra xhigh was requested for
the audits. Earlier audits reused context and a shared ﬁlesystem; audit840 received a fresh
scoped input, still with a shared ﬁlesystem. Eﬀective runtime identity, eﬀort and indepen-
dence are not independently attested. No runtime isolation, independent human peer review,
Lean formalization, certiﬁed worldwide originality or predicted assessment score is claimed.
Responsibility remains with the named author.
Limits. The coeﬃcientwise midpoint inequality is a cited input. The universal classiﬁca-
tion allows ﬁxed coordinates and requires integer, not merely real, nonemptiness where stated.
Equimodular normalization preserves regular kernel geometry; it is not a theorem for arbitrary
conﬁgurations. Our algorithm does not count general ﬁbers or produce a ﬁxed positive numer-
ical gap uniform over unbounded ﬁelds. No solution of global Jensen is claimed. Strong poly-
nomiality is an arithmetic operation bound under integer-box promises, with input-dependent
bit costs. Signiﬁcance and antecedent overlap require full-manuscript review.
References
[1] J. Leake and M. Mohammadi Yekta, Log-concavity and Approximate Counting for
Totally Unimodular Polytopes , arXiv:2609.39917v1 (30 September 2026).
https://arxiv.org/html/2609.39917v1.
9

[2] É. Tardos, A Strongly Polynomial Algorithm to Solve Combinatorial Linear Programs ,
Operations Research 34(2) (1986),250–256. doi:10.1287/opre.34.2.250.
[3] P. Csikvári and A. Imolay, Covers, orientations and factors , Electronic Journal of
Combinatorics 27(3) (2020), Paper 3.25; arXiv:1905.06678v5.
https://arxiv.org/abs/1905.06678v5.
[4] I. Heller, On linear systems with integral valued solutions , Paciﬁc Journal of Mathematics
7(3) (1957),1351–1364. https://msp.org/pjm/1957/7-3/pjm-v7-n3-p07-p.pdf .
[5] D. I. Bernstein and S. Sullivant, Unimodular binary hierarchical models ,
arXiv:1502.06131v2 (2016), Deﬁnition 1.1 and Section 2.
https://arxiv.org/pdf/1502.06131v2.
[6] P. Chervet, R. Grappe and L.-H. Robert, Box-total dual integrality, box-integrality, and
equimodular matrices, Mathematical Programming 188 (2021),319–349; online 20 May
2020. doi:10.1007/s10107-020-01514-0.
[7] F. Abu Salem, S. Gao and A. G. B. Lauder, Factoring polynomials via polytopes , author
version 7 January 2004. Author’s PDF at Oxford .
[8] G. Averkov and B. Langfeld, On the reconstruction of planar lattice-convex sets from the
covariogram, arXiv:1011.5530v3 (2012). https://arxiv.org/html/1011.5530v3.
[9] L. Eriksson, Rigidity and strongly polynomial equality tests for unimodular ﬁber counts ,
AIRR.SCIENCE, ARR-2026-0BQ1X4SGFJ8AJ8N1, v1 (27 October 2026), Working
paper. https://airr.science/papers/ARR-2026-0BQ1X4SGFJ8AJ8N1/versions/v1/.
10
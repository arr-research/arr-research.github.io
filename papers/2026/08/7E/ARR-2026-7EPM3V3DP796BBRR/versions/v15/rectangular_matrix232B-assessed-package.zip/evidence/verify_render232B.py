from pathlib import Path
import json,hashlib,zipfile,os,shutil,datetime
E=Path(r'D:\Datos\the-eriksson-programme\autonomia\evidencia-232');D=Path(r'D:\Entregas\the-eriksson-programme\2026-11-10_manuscript232');O=D/'attempt-b'
def require(v,m):
 if not v:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
for n in ['allocation','execution','download','release']:require((O/(n+'232.exit')).read_text().strip()=='0','Lifecycle '+n)
require((E/'runtime232B-backend-readback.exit').read_text().strip()=='0' and 'No active sessions found on server' in (E/'runtime232B-backend-readback.txt').read_text(),'Separate inactive readback required')
archive=O/'tep232B-review.zip';target=D/'exact232B';require(not target.exists(),'Existing extraction must be reconciled')
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('manifest.json'))
 for x in manifest:
  b=z.read(x['path']);require(len(b)==x['bytes'] and sha(b)==x['sha256'],'Payload '+x['path'])
 report=json.loads(z.read('report.json'));require(report['source_sha']=='f83ee8a84b3ecc27470ed8a92ea61eb627d86445','Sourcepin')
 require(report['status']=='RENDERED_PENDING_VISUAL_REVIEW' and len(report['tool_exits'])==10 and all(v==0 for v in report['tool_exits'].values()) and not report['layout_warnings'],'Actual rendering exits/warnings')
 require(sha(z.read('rectangular_matrix.pdf'))==report['pdf_sha256'],'PDF hash')
 for name,spec in report['source_inputs'].items():require(sha(z.read(name))==spec['sha256'] and z.read(name)==(E/'source-b'/name).read_bytes(),'Exact source '+name)
 for name in z.namelist():require(Path(name).name==name and name not in ('','.','..'),'Archive path')
 target.mkdir()
 for name in z.namelist():(target/name).write_bytes(z.read(name))
summary={'version':'232B','source_sha':report['source_sha'],'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'manifest_subjects_verified':len(manifest),'pdf_sha256':report['pdf_sha256'],'pdf_bytes':report['pdf_bytes'],'pages':report['pages'],'all10_actual_tool_exits_zero':True,'final_layout_warnings':report['layout_warnings'],'own_runtime_released_and_backend_inactive':True,'visual_QA':'PENDING','source_audit':'SEPARATE_GATE','numerical_assessment':None,'render_report':report,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(E/'render232B-verified.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');shutil.copyfile(E/'render232B-verified.json',D/'render232B-verified.json');shutil.copyfile(__file__,E/'verify_render232B.py');print(json.dumps({k:v for k,v in summary.items() if k!='render_report'}))

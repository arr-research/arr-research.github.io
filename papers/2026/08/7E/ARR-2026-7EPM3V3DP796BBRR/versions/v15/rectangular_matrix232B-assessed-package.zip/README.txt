Rectangular observations for finite matrix gradients
Exact assessed232B working-paper candidate package

Model assessments and review context
This unchanged30-page PDF has one first-round AIassessment4.10/10,4/10 overallstars; fivecriterionratings4/4/3/3/4 outof5. The native-compatible category is MAJOR_REVISION, with all three material objections OPEN. Original minor_revision opinion and the same-round clarification are both retained unabridged. They are not two reviews or human/editorial acceptance. See CURRENT-STATUS.json, original full scientific report, full contexts and author response. Prior score visible in PDF; independence unknown.

Reproduction on sanctioned Linux/Colab only
Checkout lluiseriksson/THE-ERIKSSON-PROGRAMME commit f83ee8a84b3ecc27470ed8a92ea61eb627d86445. The10 canonical corrected TeX files are in source-b, not the earlier failed-source capture. Install texlive-latex-base texlive-latex-recommended texlive-latex-extra texlive-fonts-recommended lmodern poppler-utils. With SOURCE_DATE_EPOCH=1794182400 and FORCE_SOURCE_DATE=1, run pdflatex -interaction=nonstopmode -halt-on-error rectangular_matrix.tex three times in that directory. The captured producer script, exact tool versions, full logs, real exitcodes, all30 pagePNGs and contact sheets are in production-attempt-b/tep232B-review.zip. Exact source hashes bind the producer to the commit. Document production and visual checks are not scientific/formal replay or two-clone terminal reproduction. A failed build is retained in production-attempt-a with its actual nonzero childexit. Do not rerun review to improve a score.

All manifest hashes refer to literal rawbytes, no newline normalization. The manifest excludes itself; the outer archive hash is in the companion receipt. Native v15 UUID and publication are not asserted. New234–236 results are absent, ungraded, and cannot inherit this assessment.

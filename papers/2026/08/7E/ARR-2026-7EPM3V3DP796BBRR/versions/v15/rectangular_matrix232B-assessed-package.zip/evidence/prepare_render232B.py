from pathlib import Path
import json,hashlib,subprocess,shutil,datetime
P=Path(__file__).resolve().parents[1];E=Path('D:/Datos/the-eriksson-programme/autonomia/evidencia-232')
# Run only once the full integrated-source audit and exact source identity exist.
gate=json.loads((E/'source232B-verified.json').read_text(encoding='utf-8-sig'));source=gate['source_sha'];audit=E/gate['audit_directory'];manifest=audit/'hashes.json'
if hashlib.sha256(manifest.read_bytes()).hexdigest()!=gate['audit_manifest_sha256']:raise ValueError('Exact full-source audit manifest')
v=json.loads((audit/'verdict.json').read_text(encoding='utf-8-sig'))
if v['verdict']!='accept_with_limits' or v['blocking_findings']:raise ValueError('Full-source acceptance gate')
for group in ('captures','outputs'):
 for x in json.loads(manifest.read_text(encoding='utf-8-sig'))[group]:
  p=Path(x['path']);b=p.read_bytes()
  if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256_raw']:raise ValueError('Complete actual source-review bytes')
inputs={}
for x in gate['source_files']:
 raw=subprocess.check_output(['git','-c','gc.auto=0','show',source+':'+x['path']],cwd=P)
 if hashlib.sha256(raw).hexdigest()!=x['sha256']:raise ValueError('Exact source input '+x['file'])
 inputs[x['file']]={'path':x['path'],'sha256':x['sha256']}
t=(P/'_tmp/render226C.py').read_text(encoding='utf-8-sig');start=t.index('SOURCE=');end=t.index('import os,sys')
t=t[:start]+'SOURCE='+repr(source)+'\nINPUTS='+repr(inputs)+'\n'+t[end:]
t=t.replace('tep226C','tep232B').replace('Rectangular observations for finite matrix gradients','Rectangular observations for finite matrix gradients').replace("'common','weak'","'common','weak','channel','coexact'")
out=P/'_tmp/render232B.py'
if out.exists():raise ValueError('Preserve existing render attempt')
out.write_text(t,encoding='utf-8',newline='\n');shutil.copyfile(out,E/'render232B.py')
runner=(P/'_tmp/run226C.sh').read_text(encoding='utf-8-sig').replace('2026-11-10_manuscript226/attempt-c','2026-11-10_manuscript232/attempt-b').replace('tep226-c','tep232-b').replace('render226C.py','render232B.py').replace('tep226C','tep232B').replace('226','232')
(P/'_tmp/run232B.sh').write_text(runner,encoding='utf-8',newline='\n');shutil.copyfile(P/'_tmp/run232B.sh',E/'run232B.sh')
back=(P/'_tmp/readback226C.sh').read_text(encoding='utf-8-sig').replace('tep226-c','tep232-b').replace('226C','232B').replace('226','232');(P/'_tmp/readback232B.sh').write_text(back,encoding='utf-8',newline='\n');shutil.copyfile(P/'_tmp/readback232B.sh',E/'readback232B.sh')
pre={'prepared_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'inputs':inputs,'exact_full_source_audit_manifest_sha256':gate['audit_manifest_sha256'],'execution':'NOT_YET_RUN','runtime':'Own ColabLinux CPU highmemory, unique232-a config, release then separate backend observation','production':'PDF/document rendering only, not formal or scientific theorem execution','grade':None}
(E/'production232B-preregistration.json').write_text(json.dumps(pre,indent=2)+'\n',encoding='utf-8');shutil.copyfile(__file__,E/'prepare_render232B.py');print(json.dumps({'prepared_disconnected':True,'source':source,'input_files':len(inputs),'execution':False}))

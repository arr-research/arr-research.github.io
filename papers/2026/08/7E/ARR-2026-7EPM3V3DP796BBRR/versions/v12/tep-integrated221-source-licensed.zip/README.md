# Exact integrated221B source and evidence package

Canonical95page PDF78bcb10ac82b7b920281542a311a28bf70132c73a4a1dbacf90c62b62eb9bf83,
885392bytes; twelve TeX inputs at86c19e1bd5b18cfe39f6c53685489b0d7cc75a64.
Run provenance/render221B.py only in an owned Colab Linux CPU/high-memory runtime.
It fetches and verifies all twelve exact Git blobs, records real tool exits,
compiles three passes, extracts text, renders every page and hashes the ZIP.
Prepare while disconnected and release/read back your runtime after completion.
The original renderer ZIP is a separate immutable release artifact.

programme-git contains raw Git bytes of complete source218--220 evidence directories,
proofs and MIT diagnostic scripts at7c3c21d614a74c74c57e1e8bf083b05f1e06c933.
Their own manifests/transcripts, original source reports, negative controls, runtime
records and exact source pins are retained. Normal/-O finite D=3 diagnostics agree;
these are not all-size machine proofs, two-fresh-clone reproduction or new Lean
results. Scientific replay belongs in an owned Colab Linux runtime, never Windows.
Historical217 source/evidence ZIP is nested unchanged, with its original hashes,
reports and per-artifact licence context; no old grade or verdict transfers.

Full rejected integrationA source report/captures and bounded correctiveB report
are preserved. A was rejected for five integration defects and never numerically
assessed. B corrects them and was accepted with limits. The original bare-CR
sourceA bytes remain preserved exactly, not normalized or retrospectively passed.
Source reviewers were involved/shared-context tasks, not independent or blinded.

assessment221-codex contains the first declared numerical assessment of exactB:
all original scores, objections, report and factual model/input context are retained.
No target score, inherited judgment or grade-improvement rereview is used.
Its identity/backend limitations and scientific/verification limits remain binding.
An AI assessment is not human peer review or editorial acceptance. No permission
or public receipt is created by this source package or proposed version UUID.

Selected local shell means are actual disjoint rectangles but not a global cover.
The canonical interface-discard obstruction is for a prescribed smaller form;
the offcenter slowdown is for an actual annulus. Both full cubes admit one mean.
The unrestricted global rectangular problem, novelty/priority and physical/continuum
questions remain open. PR29=20/41,TermSource0 unchanged.

Licences remain per artifact: manuscript/publication permission is separate;
new diagnostic218--220 files explicitly retain SPDX MIT; renderer and inherited
programme code retain their applicable AGPL notices. No nested original notices
are removed or relicensed. Consult the individual headers and historical packet.

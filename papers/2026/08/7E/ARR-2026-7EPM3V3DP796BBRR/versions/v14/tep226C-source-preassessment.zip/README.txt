Rectangular observations for finite matrix gradients — manuscript226C
Frozen source2d3237501569f6afac8a44d524a5d6db59f63c39.
ExactPDF SHA25628cb2a7502e05cd8588aa6294f07a7eca5e0e452cce1bf5e4f09e9ec3c89e1a6.
PDF20pages419361bytes; render archive is a separately verified companion.
This archive preserves source, all27 declared inputs, complete originalB rejection
and complete correctedC source audit. No numeric assessment is included at this
pre-assessment stage; no publication or acceptance claimed.

To reproduce document production, run reproduction/render226C.py only in an owned
ColabLinux runtime with internet/apt access. It fetches the exact six raw Git TeX
inputs and requires their frozen hashes, executes three LaTeX passes and Poppler,
records actual child exits and packages the exact render manifest. It requires
/content; it does not build Lean or run mathematical diagnostics. The sibling
source226C/ directory supports offline three-pass pdflatex rectangular_matrix.tex
in that same sanctioned Linux environment when those dependencies are installed.
SOURCE_DATE_EPOCH=1794182400 and FORCE_SOURCE_DATE=1 were used. TeX Live2023/Debian
and Poppler24.02.0 are recorded in the exact report. A different toolchain may
produce different PDF bytes: compare source, tool versions and logs, not merely
the title. This package is reproduction preparation, not two-fresh-clone replay.

Original code/source notices and repository AGPL licence are retained. External
primary papers are cited, not redistributed. No blanket relicensing or third-party
permission is asserted. AI source audit is involved same-system role separation,
not independent/blind/human peer review. No physical massgap/continuum result.

PROPOSED LINKED REVISION OF255B, SOURCE STAGE ONLY

New manuscript contains the complete259 temporal proof, the257 cutoff lemma,
fixed/bounded-motion consequences and the rapid helical counterexample,
consolidated with existing251--254. No new PDF, source acceptance, grade,
submission, revision receipt or publication is claimed by this source freeze.
The separate260 golden-orbit limitation is excluded. Full source inputs and
historical255B assessment are preserved without transferring its4/10 score.
The next gate is a separate exact-commit manuscript audit, followed by owned
Colab production with two fresh same-SHA clones and all-page visual review.
No controller credential, private job or new permission is in this package.

Scope repair260A-M1: temporal theorem is in a CYCLIC extension, restricting
to nonwrapping canonical product slices. Rapid24n wrapped example remains
cyclic-only; separate means after chart refinement need not vanish.
Original f507 source rejection/full report preserved; delta review pending.

CandidateC adds separately audited actual nonwrapping261C construction,
not an inference about splitting the cyclic witness. CandidateB was built
in two fresh clones but had observed layout defects and received no grade.
NewC full manuscript delta audit and actual PDF production/QA still required.
